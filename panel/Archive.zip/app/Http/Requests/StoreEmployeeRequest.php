<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
class StoreEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'phone' => ['nullable', 'string', 'max:50'],
            'status' => ['nullable', 'in:active,inactive'],
            'access_level' => ['nullable', 'in:admin,power_user'],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Employee name is required.',
            'email.required' => 'Employee email is required.',
            'email.email' => 'Please enter a valid employee email address.',
            'email.unique' => 'This employee email is already in use.',
            'status.in' => 'Please select a valid employee status.',
            'access_level.in' => 'Please select a valid employee access level.',
        ];
    }
}
